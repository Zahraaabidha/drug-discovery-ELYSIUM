declare module "cytoscape-fcose";
